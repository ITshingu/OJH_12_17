<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" href="/favicon.ico" type="image/x-icon">
    <title>마음가GYM</title>

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }

        .content {
            margin-top: 100px;
            margin-left: 200px;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
        }

        .board-container {
            width: 48%; /* 좌우 테이블 너비 */
        }

        .board-title {
            margin-bottom: 20px;
            font-size: 1.5em;
            color: #333;
            text-align: center;
        }

        .board-table {
            width: 700px;
            border-collapse: collapse;
        }

        .board-table th,
        .board-table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }

        .board-table th {
            background-color: thistle;
            color: white;
            font-weight: bold;
        }

        .board-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .board-table tr:hover {
            background-color: #f1f1f1;
        }
    </style>
</head>
<body>
    
    <?php require_once("inc/header.php"); ?>
    <?php require_once("social_menu.php"); ?>

    <!-- 콘텐츠 영역 -->
    <div class="content">
         <!-- 첫 번째 테이블 -->
         <div class="board-container">
            <div class="board-title">게시판 1</div>
            <table class="board-table">
                <thead>
                    <tr>
                        <th>번호</th>
                        <th>제목</th>
                        <th>작성자</th>
                        <th>작성일</th>
                        <th>조회수</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>2</td>
                        <td><a href="post_view.php?id=1">게시판 2의 제목 2</a></td>
                        <td>관리자</td>
                        <td>2024-11-21</td>
                        <td>123</td>
                    </tr>
                    <tr>
                        <td>1</td>
                        <td><a href="post_view.php?id=2">게시판 1의 제목 1</a></td>
                        <td>사용자1</td>
                        <td>2024-11-20</td>
                        <td>45</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <?php require_once("inc/footer.php"); ?>
</body>
</html>