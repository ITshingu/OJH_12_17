<!DOCTYPE html>
<html lang="ko">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>마음가GYM_회원가입</title>
</head>

<body>
    
    <?php require_once("inc/header.php"); ?>

    <main class="main_wrapper sign_up">
        <div class="progress">
            <div class="progress_step step1">
                <span class="title">STEP 1</span>
                <span>회원정보 입력</span>
            </div>
            <div class="progress_step step2">
                <span class="title">STEP 2</span>
                <span>회원가입 완료</span>
            </div>
        </div>
        <span class="join_us_title">회원가입</span>
        <div class="join_box">
            <form name="member_form" method="POST" action="member_insert.php" class="member_form">
                <div class="member_form_col">
                    <div class="member_form_row row1">
                        <div class="form id">
                            <div class="col1">아이디</div>
                            <div class="col2">
                                <input type="text" name="id">
                            </div>
                        </div>
                        <div class="clear"></div>

                        <div class="form">
                            <div class="col1">비밀번호</div>
                            <div class="col2">
                                <input type="password" name="pass">
                            </div>
                        </div>
                        <div class="clear"></div>
                        <div class="form">
                            <div class="col1">비밀번호 재확인</div>
                            <div class="col2">
                                <input type="password" name="pass_confirm">
                            </div>
                        </div>
                        <div class="clear"></div>
                        <div class="form">
                            <div class="col1">이름</div>
                            <div class="col2">
                                <input type="text" name="name">
                            </div>
                        </div>
                        <div class="form">
                            <div class="col1">전화번호</div>
                            <div class="col2">
                                <input type="text" name="phone" id="phone" placeholder="전화번호">
                                <button type="button" id="send_otp">인증번호 보내기</button>
                            </div>
                        </div>
                        <div class="form">
                            <div class="col1">인증번호</div>
                            <div class="col2">
                                <input type="text" name="otp" id="otp" placeholder="인증번호">
                                <button type="button" id="verify_otp">확인</button>
                            </div>
                        </div>
                        <div class="clear"></div>

                        <div class="form">
                            <div class="col1">성별</div>
                            <div class="col2">
                                <label>
                                    <input type="radio" name="sex" value="male"> 남자
                                </label>
                                <label>
                                    <input type="radio" name="sex" value="female"> 여자
                                </label>
                                <label>
                                    <input type="radio" name="sex" value="other"> 크레파스
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                
            </form>
        </div>
        <section>
            <button class="button_join" onclick="check_input()">가입</button>
            <button class="button_cancel"><a href="login.php">취소</a></button>
        </section>

    </main>

    <script>
        function generateOTP() {
            var otp = Math.floor(100000 + Math.random() * 900000);
            return otp;
        }

        var generatedOTP = '';

        document.getElementById("send_otp").addEventListener("click", function() {
            var phone = document.getElementById("phone").value;
            if (phone) {
                generatedOTP = generateOTP();
                alert("인증번호가 발송되었습니다: " + generatedOTP); // 실제 서비스에서는 SMS API 연동 필요
            } else {
                alert("전화번호를 입력해주세요.");
            }
        });

        document.getElementById("verify_otp").addEventListener("click", function() {
            var userOTP = document.getElementById("otp").value;
            if (userOTP === generatedOTP.toString()) {
                alert("인증 성공!");
            } else {
                alert("인증번호가 틀렸습니다. 다시 시도해주세요.");
            }
        });

        function check_input() {
            if (!generatedOTP || !document.getElementById("otp").value) {
                alert("인증번호를 입력하고 확인해주세요.");
                return false;
            }
            alert("회원가입이 완료되었습니다.");
            window.location.href = 'login.php';
            return true;
        }
    </script>
    <?php require_once("inc/footer.php"); ?>
</body>
</html>