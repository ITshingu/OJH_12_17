<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" href="/favicon.ico" type="image/x-icon">
    <title>마음가GYM</title>

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }

        .sidebar {
            position: fixed;
            left: 15%;
            top: 30%;
            transform: translateY(-50%); /* 수직 중앙 정렬 */
            width: 150px; /* 사이드바 너비 */
            background-color: thistle;
            padding: 20px 10px;
            color: white;
            display: flex;
            flex-direction: column; /* 세로 정렬 */
            align-items: flex-start; /* 왼쪽 정렬 */
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            flex-direction: column; /* 리스트 항목을 세로로 정렬 */
            gap: 10px; /* 항목 간격 */
        }
        .sidebar li {
            margin: 10px;
            font-size: 1.2em;
        }

        .sidebar a:hover {
            color: #ddd; /* 호버 시 색상 변경 */
            cursor: pointer;
        }

        .content-name {
            margin-top: 50px;
            padding: 30px;
            display: fixed;
        }

        .content-name ul {
            font-size: 50px;
            float: left ;
        }

        ul {
            padding: 0;
            display: flex;
            gap: 10px;
        }

        .image-item {
            position: absolute; /* 절대 위치 설정 */
            top: 20%; /* 상단에서의 거리 설정 */
            left: 30%; /* 왼쪽에서의 거리 설정 */
        }


        .image-container {
            position: absolute; /* 절대 위치 설정 */
            top: 20%; /* 상단에서의 거리 설정 */
            left: 30%;
            width: 40%;
            height: 60%;
            background-color: #E2E2E2;
            border-radius: 40px;
            }

            
        .background-img {
            
            width: 100%;
            height: 100%; /* 이미지가 영역을 가득 채우도록 설정 */
        }

        .overlay-text {
            position: absolute;
            top: 15%; /* 화면의 중간에 위치 */
            left: 55%;
            transform: translate(-50%, -50%); /* 정확히 중앙에 위치 */
            color: white;
            font-size: 24px;
            font-weight: bold;
        }

        .overlay-1-text {
            position: absolute;
            top: 50%; /* 화면의 중간에 위치 */
            left: 30%;
            transform: translate(-50%, -50%); /* 정확히 중앙에 위치 */
            color: white;
            font-size: 24px;
            font-weight: bold;
        }

        .foreground-img {
            position: absolute;
            top: 100px;
            bottom: 10px;
            left: 100px;
            width: 400px; /* 크기 조정 */
        }

        .center-image {
            position: absolute;
            top: 45%; /* Adjusted slightly upward from 50% */
            left: 50%;
            transform: translate(-50%, -50%);
        }

    </style>


</head>
<body>
    
    <?php require_once("inc/header.php"); ?>

    <div class="sidebar">
        <ul>
            <li><a href="recommend_home.php" style="display: inline-block; border-bottom: 4px solid Red; padding-bottom: 5px;">추천 루틴</a></li>
            <li><a href="likeRoutine_home.php" class="nav" >좋아요 루틴</a></li>
            <li><a href="myRoutine_record.php">내 루틴</a></li>
        </ul>
    </div>
    
    <div class="image-container">
        
        <div class="center-image">
            <ul style="margin-top: 80px;">
                <li>
                    <img src="img/index/cantfind.png">
                </li>
                <li style="margin-top: 100px;">
                    <p style="font-size: 30px;">아직 준비되지 않은<br>콘텐츠 입니다</p>
                </li>
            </ul>
        </div>
    </div>
    
    

        
    </ul>

    
    </ul>


    <?php require_once("inc/footer.php"); ?>
</body>
</html>