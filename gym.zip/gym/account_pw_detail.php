<!DOCTYPE html>
<html lang="ko">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>마음가GYM_비밀번호 변경</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f7f7f7;
            margin: 0;
            padding: 0;
        }

        .main_wrapper.change_pw {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 30px;
            background-color: transparent;
            box-shadow: none;
        }

        .change_pw_title {
            font-size: 24px;
            font-weight: bold;
            text-align: center;
            margin-bottom: 40px;
            color: #333;
        }

        .change_pw_box {
            width: 100%;
            max-width: 600px;
            margin: 0 auto;
        }

        .change_pw_form {
            width: 100%;
            padding: 20px;
            box-sizing: border-box;
        }

        .form {
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .form .col1 {
            font-size: 16px;
            width: 150px;
            font-weight: bold;
            color: #333;
        }

        .form .col2 {
            width: 400px;
        }

        .form input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
            color: #333;
            outline: none;
        }

        .form input:focus {
            border-color: #007bff;
        }

        .button_change_pw,
        .button_cancel {
            padding: 12px 20px;
            font-size: 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .button_change_pw {
            background-color: #007bff;
            color: white;
            margin-right: 10px;
        }

        .button_change_pw:hover {
            background-color: #0056b3;
        }

        .button_cancel {
            background-color: #f44336;
            color: white;
        }

        .button_cancel:hover {
            background-color: #d32f2f;
        }

        .button_cancel a {
            color: white;
            text-decoration: none;
        }

        section {
            text-align: center;
            margin-top: 30px;
        }
    </style>
</head>

<body>

    <?php require_once("inc/header.php"); ?>

    <main class="main_wrapper change_pw">
        <span class="change_pw_title">비밀번호 변경</span>
        <div class="change_pw_box">
            <form name="change_pw_form" method="POST" action="account_pw_detail.php" class="change_pw_form" onsubmit="return checkPasswordFields()">
                <div class="form">
                    <div class="col1">새 비밀번호</div>
                    <div class="col2">
                        <input type="password" name="new_pass" id="new_pass" placeholder="새 비밀번호" required>
                    </div>
                </div>
                <div class="form">
                    <div class="col1">비밀번호 확인</div>
                    <div class="col2">
                        <input type="password" name="new_pass_confirm" id="new_pass_confirm" placeholder="비밀번호 확인" required>
                    </div>
                </div>
            </form>
        </div>
        <section>
            <button class="button_change_pw" onclick="return checkPasswordFields()">비밀번호 변경</button>
            <button class="button_cancel"><a href="login.php">취소</a></button>
        </section>
    </main>

    <script>
        function checkPasswordFields() {
            var newPass = document.getElementById("new_pass").value;
            var confirmPass = document.getElementById("new_pass_confirm").value;

            // 빈칸이 있는지 체크
            if (newPass === "" || confirmPass === "") {
                alert("빈칸 없이 입력해주세요.");
                return false; // 폼 제출 방지
            }

            // 비밀번호와 비밀번호 확인이 일치하는지 확인
            if (newPass !== confirmPass) {
                alert("비밀번호와 비밀번호 확인이 일치하지 않습니다.");
                return false; // 폼 제출 방지
            }

            // 비밀번호가 일치하면 비밀번호가 변경되었음을 알리고 로그인 페이지로 리디렉션
            alert("비밀번호가 변경되었습니다!");

            // 3초 후 로그인 페이지로 이동
            setTimeout(function() {
                window.location.href = 'login.php'; // 로그인 페이지로 이동
            }, 3000);

            return false; // 페이지 리로드 방지
        }
    </script>

    <?php require_once("inc/footer.php"); ?>
</body>

</html>
