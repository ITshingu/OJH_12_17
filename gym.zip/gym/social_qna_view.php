<?php
    if(isset($_GET['boardID'])) { //isset은 변수가 설정되어 있으면 true를, 그렇지 않으면 false를 반환합니다
        $boardID = $_GET['boardID'];

        // echo $boardID;

        $sql = "SELECT b.boardContents, b.boardTitle, m.youName, b.regTime, b.boardView FROM board b JOIN members m ON(m.memberID = b.memberID) WHERE b.boardID = {$boardID}";
        $result = $connect -> query($sql);

        $info = $result -> fetch_array(MYSQLI_ASSOC); // fetch_array 배열로 불러오기

        echo "<tr><th>제목</th><td>".$info['boardTitle']."</td></tr>";
        echo "<tr><th>등록자</th><td>".$info['youName']."</td></tr>";
        echo "<tr><th>등록일</th><td>".date('Y-m-d', $info['regTime'])."</td></tr>";
        echo "<tr><th>조회수</th><td>".$info['boardView']."</td></tr>";
        echo "<tr><th>내용</th><td>".$info['boardContents']."</td></tr>";
    } else {
        echo "<tr><td colsapn='4'>게시글이 없습니다.</td></tr>";
    }
?>