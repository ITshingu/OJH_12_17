<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" href="/favicon.ico" type="image/x-icon">
    <title>마음가GYM</title>

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }

        .sidebar {
            position: fixed;
            left: 15%;
            top: 30%;
            transform: translateY(-50%);
            width: 150px;
            background-color: thistle;
            padding: 20px 10px;
            color: white;
            display: flex;
            flex-direction: column;
            align-items: flex-start;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .sidebar li {
            margin: 10px;
            font-size: 1.2em;
        }

        .sidebar a {
            text-decoration: none;
            color: white;
            padding: 5px 10px;
            transition: all 0.3s ease;
        }

        .sidebar a:hover {
            color: #ddd;
            cursor: pointer;
        }

        /* Center Section */
        .center {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 50vh; /* Reduced height to move up */
            margin-top: -50px; /* Additional upward adjustment */
        }

        .circle-container {
            display: flex;
            gap: 20px; /* Space between circles */
        }

        .circle-item {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .circle {
            width: 200px;
            height: 200px;
            background-color: lightblue;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 1.2em;
            font-weight: bold;
            color: white;
            text-align: center;
        }

        .circle-text {
            margin-top: 10px;
            font-size: 1em;
            color: #333;
            text-align: center;
        }

        .footer-text {
        text-align: center;
        margin: 50px 20px;
        font-size: 1.2em;
        color: #555;
    }

    .footer-text .highlight {
        font-size: 2.8em; /* 크기 조정 */
        font-weight: bold; /* 글자 굵게 */
        color: #333; /* 강조 색상 */
        line-height: 1.8; /* 줄 간격 조정 */
    }
    
    </style>
</head>
<body>
    
    <?php require_once("inc/header.php"); ?>

    <div class="sidebar">
        <ul>
            <li><a href="account_home.php" style="display: inline-block; border-bottom: 4px solid Red; padding-bottom: 5px;">홈</a></li>
            <li><a href="account_faq.php">faq</a></li>
            <li><a href="account_dm.php">dm</a></li>
        </ul>
    </div>
    
    <!-- Center Section -->
    <div class="center">
        <div class="circle-container">
            <div class="circle-item">
                <div class="circle">오준희<br><br>팀원</div>
                <div class="circle-text">개발팀의 핵심 멤버</div>
            </div>
            <div class="circle-item">
                <div class="circle">전동준<br><br>팀원</div>
                <div class="circle-text">기술 리더</div>
            </div>
            <div class="circle-item">
                <div class="circle">이어진<br><br>팀원</div>
                <div class="circle-text">UI/UX 디자이너</div>
            </div>
            <div class="circle-item">
                <div class="circle">백승범<br><br>팀원</div>
                <div class="circle-text">프로젝트 매니저</div>
            </div>
        </div>
    </div>

    <!-- Footer Text Section -->
    <div class="footer-text">
    <span class="highlight">본 마음가GYM</span> 사이트는
    헬스관련 운동 정보들을 공유하고 뿐만 아니라
    커뮤니티를 <br>운영함으로써 헬스에 관한 흥미를 높이고
    친목도 추진함으로 헬스를 정진하도록 하는 웹 사이트입니다
</div>

    <?php require_once("inc/footer.php"); ?>
</body>
</html>
