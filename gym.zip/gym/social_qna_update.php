<?php
// Database connection using PDO
function db_get_pdo() {
    $host = 'localhost';
    $port = '3306';
    $dbname = 'gym'; // Database name
    $charset = 'utf8';
    $username = 'root';
    $db_pw = ''; // Empty password (change if needed)
    $dsn = "mysql:host=$host;port=$port;dbname=$dbname;charset=$charset";
    try {
        $pdo = new PDO($dsn, $username, $db_pw);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Enable exception handling
        return $pdo;
    } catch (PDOException $e) {
        die('Connection failed: ' . $e->getMessage());
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Getting form data
    $id = $_POST['name'];                  // Writer
    $title = $_POST['title'];              // Title
    $content = $_POST['content'];          // Content
    $date = date('Y-m-d H:i:s');           // Date
    $URL = './social_qna_home.php';        // Return URL

    try {
        // Prepare and execute the insert query
        $pdo = db_get_pdo();
        $query = "INSERT INTO board (title, content, date, hit, id) 
                  VALUES (:title, :content, :date, 0, :id)";
        
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':title', $title);
        $stmt->bindParam(':content', $content);
        $stmt->bindParam(':date', $date);
        $stmt->bindParam(':id', $id);

        // Execute the query
        $stmt->execute();

        // Redirect with success message
        echo "<script>
                alert('게시글이 등록되었습니다.');
                location.replace('$URL');
              </script>";
    } catch (PDOException $e) {
        // Handle errors (e.g., if insert fails)
        echo "게시글 등록에 실패하였습니다: " . $e->getMessage();
    }
}
?>
