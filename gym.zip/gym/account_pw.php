<!DOCTYPE html>
<html lang="ko">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>마음가GYM_비밀번호 찾기</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f7f7f7;
            margin: 0;
            padding: 0;
        }

        .main_wrapper.find_pw {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 30px;
            background-color: transparent; /* 배경 제거 */
            border: none; /* 테두리 제거 */
            box-shadow: none; /* 그림자 제거 */
        }

        .find_pw_title {
            font-size: 24px;
            font-weight: bold;
            text-align: center;
            margin-bottom: 40px;
            color: #333;
        }

        .find_pw_box {
            width: 100%;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: transparent; /* 배경 투명 */
            border: none; /* 테두리 제거 */
        }

        .find_pw_form {
            width: 100%;
            padding: 20px;
            box-sizing: border-box;
        }

        .form {
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .form .col1 {
            font-size: 16px;
            width: 150px;
            font-weight: bold;
            color: #333;
        }

        .form .col2 {
            width: 400px;
        }

        .form input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc; /* 테두리 추가 */
            background-color: transparent; /* 배경 투명 */
            font-size: 16px;
            color: #333;
            outline: none;
        }

        .form input:focus {
            border-color: #007bff; /* 포커스 시 테두리 색상 */
        }

        .form button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 15px;
            font-size: 14px;
            border-radius: 4px;
            cursor: pointer;
            margin-left: 10px;
        }

        .form button:hover {
            background-color: #0056b3;
        }

        .button_find_pw,
        .button_cancel {
            padding: 12px 20px;
            font-size: 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .button_find_pw {
            background-color: #007bff;
            color: white;
            margin-right: 10px;
        }

        .button_find_pw:hover {
            background-color: #0056b3;
        }

        .button_cancel {
            background-color: #f44336;
            color: white;
        }

        .button_cancel:hover {
            background-color: #d32f2f;
        }

        .button_cancel a {
            color: white;
            text-decoration: none;
        }

        section {
            text-align: center;
            margin-top: 30px;
        }
    </style>
</head>

<body>
    
    <?php require_once("inc/header.php"); ?>

    <main class="main_wrapper find_pw">
        <span class="find_pw_title">비밀번호 찾기</span>
        <div class="find_pw_box">
            <form name="find_pw_form" method="POST" class="find_pw_form">
                <div class="form">
                    <div class="col1">아이디</div>
                    <div class="col2">
                        <input type="text" name="id" id="find_id" required>
                    </div>
                </div>
                <div class="form">
                    <div class="col1">전화번호</div>
                    <div class="col2">
                        <input type="text" name="phone" id="find_phone" placeholder="전화번호" required>
                        <button type="button" id="send_otp_find">인증번호 보내기</button>
                    </div>
                </div>
                <div class="form">
                    <div class="col1">인증번호</div>
                    <div class="col2">
                        <input type="text" name="otp" id="find_otp" placeholder="인증번호" required>
                        <button type="button" id="verify_otp_find">확인</button>
                    </div>
                </div>
            </form>
        </div>
        <section>
            <button class="button_find_pw" onclick="check_find_pw_input()">아이디 및 전화번호 확인</button>
            <button class="button_cancel"><a href="login.php">취소</a></button>
        </section>
    </main>

    <script>
        var generatedOTPFind = ''; // 인증번호 변수

        // 인증번호 생성 함수
        function generateOTP() {
            var otp = Math.floor(100000 + Math.random() * 900000);
            return otp;
        }

        // 인증번호 전송 버튼 클릭 이벤트
        document.getElementById("send_otp_find").addEventListener("click", function() {
            var phone = document.getElementById("find_phone").value;
            if (phone) {
                generatedOTPFind = generateOTP();
                alert("인증번호가 발송되었습니다: " + generatedOTPFind); // 실제 서비스에서는 SMS API 연동 필요
            } else {
                alert("전화번호를 입력해주세요.");
            }
        });

        // 인증번호 확인 버튼 클릭 이벤트
        document.getElementById("verify_otp_find").addEventListener("click", function() {
            var userOTP = document.getElementById("find_otp").value;
            if (userOTP === generatedOTPFind.toString()) {
                alert("인증 성공!");
            } else {
                alert("인증번호가 틀렸습니다. 다시 시도해주세요.");
            }
        });

        // 아이디와 전화번호 확인 후 비밀번호 변경 페이지로 이동
        function check_find_pw_input() {
            var id = document.getElementById("find_id").value;
            var phone = document.getElementById("find_phone").value;

            // 필수 입력 값 체크
            if (!id || !phone) {
                alert("아이디와 전화번호를 모두 입력해주세요.");
                return false;
            }

            // 인증번호 확인
            if (!generatedOTPFind || !document.getElementById("find_otp").value) {
                alert("인증번호를 입력하고 확인해주세요.");
                return false;
            }

            // 인증번호 일치 확인
            var userOTP = document.getElementById("find_otp").value;
            if (userOTP !== generatedOTPFind.toString()) {
                alert("인증번호가 틀렸습니다. 다시 시도해주세요.");
                return false;
            }

            // 아이디와 전화번호가 일치하면 비밀번호 변경 페이지로 이동
            alert("아이디와 전화번호 확인 성공! 비밀번호 변경 페이지로 이동합니다.");
            window.location.href = 'account_pw_detail.php?id=' + encodeURIComponent(id) + '&phone=' + encodeURIComponent(phone);
        }
    </script>

    <?php require_once("inc/footer.php"); ?>
</body>
</html>
