<footer>
        
        <div class="footer_haru_info">
            <span class="about_haru_title">마음가GYM</span>
            
            <ul>
                <li>상호 : 마음가GYM</li>
                <li>
                    <address>사업장 소재지 : 경기도 성남시 중원구 광명로 377 남관 111호</address>
                </li>
                <li>대표 이사 : 오준희</li>
                <li>대표 전화 : 010-7765-9422</li>
            </ul>
            <ul>
                <li>HEARTGYM(c) 2024 GYM ALL RIGHT RESERVED.</li>
            </ul>
        </div>
    </footer>