<?php require_once("session.php");?>

<div id="header_wrapper">
        <header>
            <!-- <ul class="util_nav">
                <?php

                if (isset($_SESSION['member_id']) === false){
                ?>
                <li class="util_nav01">
                    <a href="sign_up.php"><span>회원가입</span></a>
                </li>
                <li class="util_nav02">
                    <a href="#"><span>고객센터</span></a>
                </li>
                <li class="util_nav03">
                    <a href="login.php"><span>로그인</span></a>
                </li>
                <?php
                }else{
                ?>
                <li class="util_nav01">
                    <a href="my-page_order.php"><span>마이페이지</span></a>
                </li>
                <li class="util_nav02">
                    <a href="#"><span>고객센터</span></a>
                </li>
                <li class="util_nav03">
                    <a href="logout.php"><span>로그아웃</span></a>
                </li>
                <?php
                }
                ?>


                
            </ul> -->
            <div class="main_nav">
                <a href="index.php" class="logo_link_index">
                    <div class="logo_wrapper">
                        <img class="logo_img_icon" src="img/index/gym_logo.png" alt="">
                        <span class="logo">마</span>
                        <span class="logo">음</span>
                        <span class="logo">가</span>
                        <span class="logo">G</span>
                        <span class="logo">Y</span>
                        <span class="logo">M</span>
                    </div>
                </a>

                <!--검색창-->
                <a href="index.php">
                <div class="like_nav">
                    <img class="logo_img_home_record_social_account" src="img/index/home.png" alt="">
                    <span class="like_nav_title">HOME</span>
                </div>
                </a>
                <a href="recommend_home.php">
                    <div class="cart_nav">
                    <img class="logo_img_home_record_social_account" src="img/index/record.png" alt="">
                    <span class="cart_nav_title">ROUTINE</span>
                </div>
                </a>
                <a href="social_home.php">
                    <div class="my_page_nav">
                    <img class="logo_img_home_record_social_account" src="img/index/social.png" alt="">
                    <span class="my_page_nav_title">SOCIAL</span>
                </div>
                </a>

                <a href="account_home.php">
                    <div class="my_page_nav">
                    <img class="logo_img_home_record_social_account" src="img/index/account.png" alt="">
                    <span class="my_page_nav_title">ACCOUNT</span>
                </div>
                </a>

                <a href="login.php">
                    <div class="my_page_nav">
                    <img class="logo_img_home_record_social_account" src="img/index/account.png" alt="">
                    <span class="my_page_nav_title">LOGIN</span>
                </div>
                </a>

                <div class="search_wrapper">
                    <fieldset class="field-container">
                        <input type="text" placeholder="Search..." class="field" />
                        <div class="icons-container">
                            <div class="icon-search"></div>
                    </fieldset>
                </div>
                
<!--                <div class="hot_issue_wrapper">
                    <div class="hot_issue_under_line">
                        <div class="hot_issue">
                            <ul id="ticker_01" class="ticker">
                                <li><span class="rank">1. </span><a href="#">가을신상</a></li>
                                <li><span class="rank">2. </span><a href="#">아우터</a></li>
                                <li><span class="rank">3. </span><a href="#">가방신상</a></li>
                                <li><span class="rank">4. </span><a href="#">코트</a></li>
                            </ul>
                        </div>
                        <i class="fas fa-caret-down"></i>
                    </div> 
-->

                </div>
            </div>
        </header>
    </div>