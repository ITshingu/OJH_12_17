<?php 
if (isset($_SESSION) === false){session_start();}
?>