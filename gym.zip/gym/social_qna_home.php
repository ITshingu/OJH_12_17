<?php 
// Database connection function using PDO
function db_get_pdo()
{
    $host = 'localhost';
    $port = '3306';
    $dbname = 'gym'; // Change to your actual database name
    $charset = 'utf8';
    $username = 'root'; // Replace with your database username
    $db_pw = ""; // Replace with your database password
    $dsn = "mysql:host=$host;port=$port;dbname=$dbname;charset=$charset";
    try {
        $pdo = new PDO($dsn, $username, $db_pw);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Set PDO error mode to exception
        return $pdo;
    } catch (PDOException $e) {
        echo "Connection failed: " . $e->getMessage();
        return null;
    }
}

// Function to retrieve data (SELECT queries)
function db_select($query, $param = array())
{
    $pdo = db_get_pdo();
    try {
        $st = $pdo->prepare($query);
        $st->execute($param);
        $result = $st->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    } catch (PDOException $ex) {
        return false;
    } finally {
        $pdo = null;
    }
}

// Function to insert data (INSERT queries)
function db_insert($query, $param = array())
{
    $pdo = db_get_pdo();
    try {
        $st = $pdo->prepare($query);
        $result = $st->execute($param);
        $last_id = $pdo->lastInsertId();
        if ($result) {
            return $last_id;
        } else {
            return false;
        }
    } catch (PDOException $ex) {
        return false;
    } finally {
        $pdo = null;
    }
}

// Function to update or delete data (UPDATE, DELETE queries)
function db_update_delete($query, $param = array())
{
    $pdo = db_get_pdo();
    try {
        $st = $pdo->prepare($query);
        $result = $st->execute($param);
        return $result;
    } catch (PDOException $ex) {
        return false;
    } finally {
        $pdo = null;
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <style>
        table {
            border-top: 1px solid #444444;
            border-collapse: separate; /* border-collapse를 separate로 설정하여 border-spacing 적용 */
            margin-top: 20px; /* 테이블 상단 여백 20px */
            margin-bottom: 20px; /* 테이블 하단 여백 20px */
            width: 100%; /* 테이블 넓이 100% 설정 */
        }

        thead {
            background-color: #f5f5f5; /* 헤더 배경 색 */
        }

        thead tr {
            border-bottom: 2px solid #8e8e8e; /* 헤더 하단 구분선 */
        }

        thead th {
            padding: 20px 10px; /* 헤더 셀 상하 여백 추가 */
            text-align: center;
        }

        tbody {
            border-spacing: 0 10px; /* tbody 내부에 10px의 여백을 추가 */
        }

        tbody tr {
            border-bottom: 1px solid #444444; /* 각 행 사이에 구분선 추가 */
            padding-bottom: 10px; /* 각 행의 아래쪽 여백을 10px 추가 */
        }

        td, th {
            padding: 20px 10px; /* 셀에 상하좌우 여백 추가 */
            text-align: center;
        }

        table .even {
            background: #efefef; /* 짝수 행 배경색 */
        }

        .text {
            text-align: center;
            padding-top: 20px;
            color: #000000;
            margin-top: 20px; /* 제목과 테이블 간의 여백 20px 추가 */
        }

        .text:hover {
            text-decoration: underline;
        }

        a:link, a:visited {
            color: #57A0EE;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        .write-btn {
            cursor: pointer;
            padding: 10px 20px;
            background-color: #57A0EE;
            color: white;
            border: none;
            font-size: 16px;
            text-align: center;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .write-btn:hover {
            background-color: #4590d0;
        }
    </style>
</head>

<body>
    <?php
    // 게시글 목록 조회
    $query = "SELECT * FROM board ORDER BY number DESC";  // 역순 출력
    $posts = db_select($query); // db_select로 게시글 가져오기
    
    // 게시글이 있는지 확인
    if ($posts) {
        $total = count($posts); // 전체 게시글 수
    }
    ?>
    <?php require_once("inc/header.php"); ?>
    <?php require_once("social_menu.php"); ?>
    
    <p style="font-size:25px; text-align:center; margin-top: 40px;"><b>Q n A 게시판</b></p>

    <div class="text">
        <!-- 제목과 테이블 사이에 여백을 추가 -->
    </div>

    <table>
        <thead>
            <tr>
                <th style="width:50px;">번호</th>
                <th style="width:500px;">제목</th>
                <th style="width:100px;">작성자</th>
                <th style="width:200px;">날짜</th>
                <th style="width:50px;">조회수</th>
            </tr>
        </thead>

        <tbody>
            <?php
            $index = 0; // 인덱스 카운터 추가 (짝수/홀수 행을 구분하기 위함)
            if ($posts) {
                foreach ($posts as $row) { // Loop through fetched posts
                    $class = ($index % 2 == 0) ? 'even' : '';  // 짝수 행에 클래스를 적용
                    ?>
                    <tr class="<?php echo $class; ?>">
                        <td style="width:50px;"><?php echo $total; ?></td>
                        <td style="width:500px;">
                            <a href="read.php?number=<?php echo $row['number']; ?>">
                                <?php echo $row['title']; ?>
                            </a>
                        </td>
                        <td style="width: 100px;"><?php echo $row['id']; ?></td>
                        <td style="width: 200px;"><?php echo $row['date']; ?></td>
                        <td style="width: 50px;"><?php echo $row['hit']; ?></td>
                    </tr>
                    <?php
                    $total--;  // 전체 게시글 수 감소
                    $index++;  // 인덱스 카운터 증가
                }
            } else {
                echo "<tr><td colspan='5'>No posts found</td></tr>";
            }
            ?>
        </tbody>
    </table>

    <div class="text">
        <!-- 글쓰기 버튼을 input 태그로 수정 -->
        <input type="button" class="write-btn" value="글쓰기" onclick="location.href='./social_qna_write.php'">
    </div>
    <?php require_once("inc/footer.php"); ?>
</body>

</html>
