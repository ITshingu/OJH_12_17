<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" href="/favicon.ico" type="image/x-icon">
    <title>마음가GYM</title>

    <style>

        .left-box{
            font-size: 35px;
            margin-top: 50px;
            border-bottom: 2px solid black;
        }

        ul {
            padding: 0;
            display: flex;
            gap: 10px;
        }

        .image-item {
            margin-top: 50px;
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 40%;
            height: auto;
        }

        .image-text {
            margin-bottom: 5px; /* 이미지와 텍스트 사이 간격 */
            color: #333;
            font-size: 1.2em;
            font-weight: bold;
            text-align: center;
        }

        .image-item img {
            width: 300px;
            height: 800px;
            display: block;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }

        .sidebar {
            position: fixed;
            left: 15%;
            top: 30%;
            transform: translateY(-50%); /* 수직 중앙 정렬 */
            width: 150px; /* 사이드바 너비 */
            background-color: thistle;
            padding: 20px 10px;
            color: white;
            display: flex;
            flex-direction: column; /* 세로 정렬 */
            align-items: flex-start; /* 왼쪽 정렬 */
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            flex-direction: column; /* 리스트 항목을 세로로 정렬 */
            gap: 10px; /* 항목 간격 */
        }
        .sidebar li {
            margin: 10px;
            font-size: 1.2em;
        }

        .sidebar a:hover {
            color: #ddd; /* 호버 시 색상 변경 */
            cursor: pointer;
        }

        .content-name {
            padding: 20px 10px;
            display: flex;
        }

        .content-name ul {
            font-size: 50px;
            float: left ;
        }



    </style>

</head>
<body>
    
    <?php require_once("inc/header.php"); ?>


    <div class="sidebar">
        <ul>
            <li><a href="recommend_home.php" class="nav" style="display: inline-block; border-bottom: 4px solid Red; padding-bottom: 5px;">추천 루틴</a></li>
            <li><a href="likeRoutine_home.php" >좋아요 루틴</a></li>
            <li><a href="myRoutine_record.php">내 루틴</a></li>
        </ul>
    </div>

    <div class="content-name">
        <ul>
            추천 루틴
        </ul>
    </div>

    <ul>
        <li class="image-item">
            <span class="image-text">등 운동</span>
            <a href="recommand_home_detail_back.php">
            <img src="img/routine/backback.jpg" alt="">
            </a>
        </li>
        <li class="image-item">
            <span class="image-text">가슴 운동</span>
            <a href="recommand_home_detail_chest.php">
            <img src="img/routine/chestchest.jpg" alt="">
            </a>
        </li>
        <li class="image-item">
            <span class="image-text">하체 운동</span>
            <a href="recommand_home_detail_leg.php">
            <img src="img/routine/legleg.jpg" alt="">
            </a>
        </li>
        <li class="image-item">
            <span class="image-text">유산소</span>
            <a href="recommand_home_detail_cardio.php">
            <img src="img/routine/cardiocardio.jpg" alt="">
            </a>
        </li>
        

        
    </ul>



    <?php require_once("inc/footer.php"); ?>
</body>
</html>