<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" href="/favicon.ico" type="image/x-icon">
    <title>마음가GYM</title>

    <style>
        /* 기본 스타일 설정 */
body {
    margin: 0;
    font-family: Arial, sans-serif;
}

/* 사이드바 스타일 */
.sidebar {
    position: fixed;
    left: 15%;
    top: 30%;
    transform: translateY(-50%); /* 수직 중앙 정렬 */
    width: 150px; /* 사이드바 너비 */
    background-color: thistle;
    padding: 20px 10px;
    color: white;
    display: flex;
    flex-direction: column; /* 세로 정렬 */
    align-items: flex-start; /* 왼쪽 정렬 */
}

.sidebar ul {
    list-style: none;
    padding: 0;
    margin: 0;
    display: flex;
    flex-direction: column; /* 리스트 항목을 세로로 정렬 */
    gap: 10px; /* 항목 간격 */
}

.sidebar li {
    margin: 10px;
    font-size: 1.2em;
}

.sidebar a:hover {
    color: #ddd; /* 호버 시 색상 변경 */
    cursor: pointer;
}

/* 루틴 제목 스타일 */
.content-name {
    padding: 20px 10px;
    display: flex;
}

.content-name ul {
    font-size: 50px;
    float: left;
}

/* 그래프 영역 설정 */
.graphhome {
    position: fixed;
    top: 25%;
    left: 30%;
}

/* 그래프 wrapper */
.graphWrap {
    position: relative;
    width: 1300px;  /* 그래프 영역의 너비 */
    height: 600px;  /* 그래프 영역의 높이 */
    margin: 20px auto 0;
    border-left: 1px solid #aaa;
    border-bottom: 1px solid #aaa;
}

/* 바를 담을 부모 div 설정 */
.graph-container {
    position: relative;
    width: 100%;  /* 부모 div 너비를 그래프 영역에 맞게 설정 */
    height: 100%; /* 부모 div 높이를 그래프 영역에 맞게 설정 */
}

/* 바 스타일 */
.graph-container .bar {
    position: absolute;
    bottom: 0;
    width: 5px;  /* 바의 너비를 2px로 설정 */
    background-color: red;  /* 바의 색상 */
    border-radius: 5px;  /* 바의 모서리를 둥글게 */
    animation: barAnimation 2s forwards;  /* 애니메이션 적용 */
    height: 0;  /* 기본적으로 높이를 0으로 설정 */
}

/* 애니메이션 키프레임 */
@keyframes barAnimation {
    from {
        height: 0;
    }
    to {
        height: var(--height);  /* JavaScript에서 설정된 높이로 변경 */
    }
}

/* 왼쪽 텍스트 스타일 */
.left-text {
    position: absolute;
    top: 0;
    left: -50px;  /* 그래프 바 왼쪽 여백 */
    font-size: 18px;
    color: black;
}

/* 각 텍스트의 위치를 차례대로 배치 */
.left-text p {
    margin: 0;
    position: absolute;
    left: 10px;
}

/* 아래쪽 텍스트 */ 
/* 아래쪽 텍스트 */
.bottom-text {
    position: absolute;
    bottom: -30px;  /* 그래프 바 아래쪽 여백 */
    left: 50%;
    transform: translateX(-50%);
    font-size: 18px;
    color: black;
    width: 103%; /* 그래프 영역과 동일한 너비로 설정 */
    display: flex;
    justify-content: space-between; /* 텍스트들을 균등 배치 */
    padding: 0 35px; /* 그래프 시작과 동일한 여백 */
}   


.bottom-label {
    flex: 1;
    text-align: center;
}

.bb{
    position: absolute;
    bottom: 20%;
    right: 30%;
}

.bbbtn{
    width: 200px;
    height: 50px;
    border-radius: 30px;
    font-size: 20px;
}




    </style>

</head>
<body>
    
    <?php require_once("inc/header.php"); ?>


    <div class="content-name">
        <ul>
            내 루틴
        </ul>
    </div>


    


    <div>
        <div class="sidebar">
            <ul>
                <li><a href="recommend_home.php">추천 루틴</a></li>
                <li><a href="likeRoutine_home.php">좋아요 루틴</a></li>
                <li><a href="myRoutine_record.php" class="nav" style="display: inline-block; border-bottom: 4px solid Red; padding-bottom: 5px;">내 루틴</a></li>
            </ul>
        </div>
    </div>

    
    <div>
        <div class="graphhome">
        <p style="padding-bottom: 20px; font-size: 20px;">y축&nbsp;&nbsp;:&nbsp;&nbsp;시간(분)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;x축&nbsp;&nbsp;:&nbsp;&nbsp;날짜(일)</p>
            <div class="graphWrap">
                <div class="graph-container"> <!-- 바를 담을 부모 div -->
                    <!-- 30개의 그래프 바 생성 -->
                    <?php
                        // 30개의 바를 생성
                        for ($i = 1; $i <= 30; $i++) {
                            // 각 바의 랜덤 높이를 설정
                            $randomHeight = rand(50, 500);
                            echo "<div class='bar' data-height='$randomHeight'></div>";
                        }
                    ?>
                </div>

                <div class="left-text">
                
            </div>
            <!-- 아래쪽 텍스트 -->
            <!-- 아래쪽 텍스트 1부터 30까지 출력 -->
            <div class="bottom-text">
                <?php
                    for ($i = 1; $i <= 30; $i++) {
                        echo "<span class='bottom-label'>$i</span>";
                    }
                ?>
            </div>
            
            </div>
        </div>
    </div>

    <div class="bb">
        <ul>
            <li>
                <button type="button" class="bbbtn">등록/수정하기</button>
                <button type="button" class="bbbtn">삭제하기</button>
            </li>
        </ul>
    </div>


<script src="js/graph.js"></script>
    
        

    <?php require_once("inc/footer.php"); ?>
</body>
</html>