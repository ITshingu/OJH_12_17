<!DOCTYPE html>
<html lang="ko">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/account_id.css">
    <title>마음가GYM_아이디 찾기</title>
</head>

<?php require_once("inc/header.php"); ?>

    <h1 class="title">아이디 찾기</h1>
    <div class="join_box">
        <form name="find_id_form" method="POST" class="find_id_form">
            <div class="form_row">
                <label for="name">이름</label>
                <input type="text" name="name" id="name" placeholder="이름을 입력하세요" required>
            </div>
            <div class="form_row">
                <label for="phone">전화번호</label>
                <div class="input_group">
                    <input type="text" name="phone" id="phone" placeholder="전화번호를 입력하세요" required>
                    <button type="button" id="send_otp">인증번호 보내기</button>
                </div>
            </div>
            <div class="form_row">
                <label for="otp">인증번호</label>
                <div class="input_group">
                    <input type="text" name="otp" id="otp" placeholder="인증번호를 입력하세요" required>
                    <button type="button" id="verify_otp">확인</button>
                </div>
            </div>
        </form>
    </div>
    <section class="button_section">
        <button class="button_submit">확인</button>
        <button class="button_cancel"><a href="login.php">취소</a></button>
    </section>
</main>
</main>

<script>
    function generateOTP() {
        var otp = Math.floor(100000 + Math.random() * 900000);
        return otp;
    }

    var generatedOTP = '';

    document.getElementById("send_otp").addEventListener("click", function() {
        var phone = document.getElementById("phone").value;
        if (phone) {
            generatedOTP = generateOTP();
            alert("인증번호가 발송되었습니다: " + generatedOTP); // 실제 서비스에서는 SMS API 연동 필요
        } else {
            alert("전화번호를 입력해주세요.");
        }
    });

    document.getElementById("verify_otp").addEventListener("click", function() {
        var userOTP = document.getElementById("otp").value;
        if (userOTP === generatedOTP.toString()) {
            alert("인증 성공!");
        } else {
            alert("인증번호가 틀렸습니다. 다시 시도해주세요.");
        }
    });

    function check_input() {
        if (!generatedOTP || !document.getElementById("otp").value) {
            alert("인증번호를 입력하고 확인해주세요.");
            return false;
        }
        alert("회원가입이 완료되었습니다.");
        window.location.href = 'login.php';
        return true;
    }
</script>
<?php require_once("inc/footer.php"); ?>

</html>