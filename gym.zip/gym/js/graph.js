window.onload = function() {
    // 모든 .bar 요소를 가져옵니다
    const bars = document.querySelectorAll('.bar');
    const graphWrap = document.querySelector('.graphWrap');  // 그래프 영역 가져오기
    const totalBars = bars.length; // 바의 총 개수 (30개)
    const barWidth = (graphWrap.offsetWidth - 50) / (totalBars - 1); // 첫 번째 바의 여백을 50px로 두고 나머지 바들을 균등하게 분배

    // 첫 번째 바에 50px 여백을 추가
    const initialOffset = 50;

    // 각 바에 대해 동작
    bars.forEach((bar, index) => {
        // data-height 값을 읽어옵니다
        const height = bar.getAttribute('data-height');
        
        // 첫 번째 바는 50px 여백을 두고, 그 이후 바들은 균등하게 분배된 너비로 배치
        const left = index === 0 ? initialOffset : (initialOffset + (index - 1) * barWidth); 

        // CSS 변수로 height 값을 설정하고, left 값을 설정합니다
        bar.style.setProperty('--height', height + 'px'); // 높이 값 설정
        bar.style.left = left + 'px'; // 바의 위치 설정
    });
    
    // 아래쪽 텍스트를 그래프와 맞춰서 설정
    const bottomText = document.querySelector('.bottom-text');
    const bottomTextSpans = bottomText.querySelectorAll('span');
    
    bottomTextSpans.forEach((span, index) => {
        // 1부터 9는 "01" 형태로, 그 외는 그대로 숫자
        let text = index + 1; // 1부터 30까지 숫자 생성
        
        // 1~9일 경우 "01", "02" 형태로 바꿔줌
        if (text < 10) {
            text = "0" + text;
        }

        span.textContent = text;  // span에 숫자 넣기

        // 텍스트의 left 값을 바와 동일한 방식으로 설정
        const left = index === 0 ? initialOffset : (initialOffset + (index - 1) * barWidth); 
        span.style.left = left + 'px';
    });

    // 왼쪽 텍스트 배치
    const leftTextContainer = document.querySelector('.left-text');
    
    // 0부터 120까지 30 단위로 텍스트 배치
    const leftTextValues = [0, 30, 60, 90, 120];
	leftTextValues.reverse();
    
    leftTextValues.forEach((value, index) => {
        const p = document.createElement('p');
        p.textContent = value;  // 숫자 넣기
        
        // 텍스트의 top 값은 각 바의 높이에 맞게 배치
        const topPosition = (index * (graphWrap.offsetHeight / 4)) + 'px'; // 4등분하여 배치
        
        p.style.top = topPosition;
        leftTextContainer.appendChild(p);
    });
};
