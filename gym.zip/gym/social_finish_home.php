<?php
session_start(); // 세션 시작

// 좋아요 상태 초기화 (필요한 경우)
// $_SESSION['liked_posts'] = [];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $postId = $_POST['postId'];
    if (isset($_SESSION['liked_posts'][$postId])) {
        unset($_SESSION['liked_posts'][$postId]); // 좋아요 취소
    } else {
        $_SESSION['liked_posts'][$postId] = true; // 좋아요
    }
    echo json_encode(['status' => 'success']);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" href="/favicon.ico" type="image/x-icon">
    <title>마음가GYM</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .card-container {
            display: grid;
            grid-template-columns: repeat(3, 1fr); /* 3열 */
            gap: 20px;
            width: 80%; /* 전체 너비의 80% */
            max-width: 1200px;
            margin: 0 auto;
        }
        .card {
            background-color: white;
            border: 1px solid #ddd;
            border-radius: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            height: 200px;
            cursor: pointer;
            transition: transform 0.3s ease;
        }
        .card:hover {
            transform: scale(1.05); /* 카드 확대 효과 */
        }
        .card-content {
            padding: 20px;
            text-align: center;
            flex-grow: 1;
        }
        .card-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            border-top: 1px solid #ddd;
        }
        .card-footer span {
            font-size: 14px;
            color: #555;
        }
        .card-footer .icons {
            display: flex;
            gap: 10px;
        }
        .card-footer .icon {
            font-size: 16px;
            cursor: pointer;
            color: #ccc; /* 기본 빈 하트 색상 */
            transition: color 0.3s ease;
        }
        .card-footer .icon.filled {
            color: #e74c3c; /* 채워진 하트 색상 */
        }
    </style>
</head>
<body>

    <?php require_once("inc/header.php"); ?>

    <div class="card-container">
        <!-- 카드 1 -->
        <div class="card" onclick="openPopup('post_view.php?id=1')">
            <div class="card-content">글 제목 1</div>
            <img src="img/oh.png" width="385px" height="100px">
            <div class="card-footer">

                <span>글 제목 1</span>
                <div class="icons">
                    <span class="icon heart-icon" onclick="toggleHeart(event, 1)">♡</span>
                    <span class="icon" onclick="openPopup('post_view.php?id=1')">💬</span>
                </div>
            </div>
        </div>
        <!-- 카드 2 -->
        <div class="card" onclick="openPopup('post_view.php?id=2')">
            <div class="card-content">글 제목 2</div>
            <div class="card-footer">
                <span>글 제목 2</span>
                <div class="icons">
                    <span class="icon heart-icon" onclick="toggleHeart(event, 2)">♡</span>
                    <span class="icon" onclick="openPopup('post_view.php?id=2')">💬</span>
                </div>
            </div>
        </div>
        <!-- 카드 3 -->
        <div class="card" onclick="openPopup('post_view.php?id=3')">
            <div class="card-content">글 제목 3</div>
            <div class="card-footer">
                <span>글 제목 3</span>
                <div class="icons">
                    <span class="icon heart-icon" onclick="toggleHeart(event, 3)">♡</span>
                    <span class="icon" onclick="openPopup('post_view.php?id=3')">💬</span>
                </div>
            </div>
        </div>
        <!-- 카드 4 -->
        <div class="card" onclick="openPopup('post_view.php?id=4')">
            <div class="card-content">글 제목 4</div>
            <div class="card-footer">
                <span>글 제목 4</span>
                <div class="icons">
                    <span class="icon heart-icon" onclick="toggleHeart(event, 4)">♡</span>
                    <span class="icon" onclick="openPopup('post_view.php?id=4')">💬</span>
                </div>
            </div>
        </div>
        <!-- 카드 5 -->
        <div class="card" onclick="openPopup('post_view.php?id=5')">
            <div class="card-content">글 제목 5</div>
            <div class="card-footer">
                <span>글 제목 5</span>
                <div class="icons">
                    <span class="icon heart-icon" onclick="toggleHeart(event, 5)">♡</span>
                    <span class="icon" onclick="openPopup('post_view.php?id=5')">💬</span>
                </div>
            </div>
        </div>
        <!-- 카드 6 -->
        <div class="card" onclick="openPopup('post_view.php?id=6')">
            <div class="card-content">글 제목 6</div>
            <div class="card-footer">
                <span>글 제목 6</span>
                <div class="icons">
                    <span class="icon heart-icon" onclick="toggleHeart(event, 6)">♡</span>
                    <span class="icon" onclick="openPopup('post_view.php?id=6')">💬</span>
                </div>
            </div>
        </div>
    </div>

    <?php require_once("inc/footer.php"); ?>

    <script>
        // 하트 토글 기능 및 세션 저장
        function toggleHeart(event, postId) {
            event.stopPropagation(); // 부모 요소의 클릭 이벤트가 실행되지 않도록 중단
            const heart = event.target;

            if (heart.textContent === "♡") {
                heart.textContent = "❤️"; // 채워진 하트로 변경
                heart.classList.add("filled");
            } else {
                heart.textContent = "♡"; // 빈 하트로 변경
                heart.classList.remove("filled");
            }

            // 좋아요 상태를 서버에 전달
            const xhr = new XMLHttpRequest();
            xhr.open("POST", "index.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.send("postId=" + postId);
        }

        // 팝업 열기
        function openPopup(url) {
            window.open(url, 'popupWindow', 'width=600,height=400,scrollbars=yes');
        }

        // 초기 좋아요 상태 설정
        document.addEventListener('DOMContentLoaded', function() {
            const likedPosts = <?php echo json_encode(isset($_SESSION['liked_posts']) ? $_SESSION['liked_posts'] : []); ?>;
            Object.keys(likedPosts).forEach(postId => {
                const heart = document.querySelector(heart-icon[onclick*="toggleHeart(event, ${postId})"]);
                if (heart) {
                    heart.textContent = "❤️";
                    heart.classList.add("filled");
                }
            });
        });
    </script>

</body>
</html>