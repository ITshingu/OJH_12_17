<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>마음가GYM</title>
    <style>
        /* General styles */
        html, body {
            height: 100%;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: Arial, sans-serif;
        }

        /* 사이드바 스타일 */
        .sidebar {
            position: fixed; /* 뷰포트에 상대적으로 고정된 위치 */
            left: 20%; /* 왼쪽 위치 조정 */
            top: 30%; /* 중앙에서 위로 약간 이동 */
            transform: translateY(-50%); /* 정확하게 수직 중앙에 오도록 조정 */
            background-color: thistle;
            padding: 30px; /* padding을 30px로 늘려서 배경 크기 증가 */
            color: white;
            display: flex;
            flex-direction: column;
            align-items: flex-start;
        }

        /* List 스타일 */
        .sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        /* 각 항목에 글자 위 간격 10px 추가 */
        .sidebar li {
            font-size: 1.2em;
            margin-top: 10px; /* 글자 위 간격을 10px로 설정 */
        }

        /* 링크 스타일 */
        .sidebar a {
            text-decoration: none;
            color: white;
            padding: 5px 10px;
            transition: all 0.3s ease;
        }

        /* Hover 효과 */
        .sidebar a:hover {
            color: #ddd;
            cursor: pointer;
        }

    </style>
</head>
<body>

    <div class="sidebar">
        <ul>
            <li><a href="social_qna_home.php">Q&A</a></li>
            <li><a href="social_finish_home.php">오운완</a></li>
            <li><a href="social_like.php">좋아요</a></li>
        </ul>
    </div>

</body>
</html>
