<?php
// 데이터베이스 연결
include('db_connect.php');

// 게시글 ID 가져오기
$id = $_GET['id'];

// SQL 쿼리: 해당 게시글의 상세 정보를 가져오기
$sql = "SELECT * FROM board WHERE id = $id";
$result = $connect->query($sql);

if ($result->num_rows > 0) {
    // 결과 출력
    $row = $result->fetch_assoc();
    echo "<div class='board-view'>";
    echo "<h1>" . htmlspecialchars($row['title']) . "</h1>";
    echo "<p>작성자: " . htmlspecialchars($row['name']) . "</p>";
    echo "<p>작성일: " . $row['regTime'] . "</p>";
    echo "<p>" . nl2br(htmlspecialchars($row['content'])) . "</p>";  // 내용 출력
    echo "<p>조회수: " . $row['viewCount'] . "</p>";  // 조회수 출력
    echo "</div>";

    // 조회수 증가
    $connect->query("UPDATE board SET viewCount = viewCount + 1 WHERE id = $id");
} else {
    echo "<p>해당 게시글이 없습니다.</p>";
}
?>
